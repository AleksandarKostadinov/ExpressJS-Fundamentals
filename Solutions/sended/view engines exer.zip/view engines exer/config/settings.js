module.exports = {
  development: {
    port: 5000,
    db: 'mongodb://localhost:27017/booklibraryexer'
  }
}
