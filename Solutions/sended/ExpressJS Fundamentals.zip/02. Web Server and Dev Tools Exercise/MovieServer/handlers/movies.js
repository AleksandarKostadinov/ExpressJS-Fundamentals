let db = require("../config/dataBase");
const qs = require("querystring");

const moviePlaceholder = "{{replace-me}}";
const movieTemplate = ` <div class="movie">
                            <img class="moviePoster" src="${moviePlaceholder}"/>          
                        </div>

`

function moviesHandler(req, res) {
    if (req.path === "/movie/all") {
        let moviesHtml = "";
        db.map(m => {
            moviesHtml += movieTemplate.replace(moviePlaceholder, decodeURIComponent(m.moviePoster));
        });


        res.sendHtml("./views/viewAll.html", 200, moviesHtml);
    } else if (req.path === "/movie/add" && req.method === "GET") {
        res.sendHtml("./views/addMovie.html", 200);
    } else if (req.path === "/movie/add" && req.method === "POST") {
        let body = [];
        req.on('data', (chunk) => {
            body.push(chunk);
        }).on('end', () => {
            body = Buffer.concat(body).toString();
            // at this point, `body` has the entire request body stored in it as a string
            let movieData = qs.parse(body);
            console.log(movieData);

            db.push(movieData);

            res.sendHtml("./views/addMovie.html", 200)
        });
    } else {
        return true;
    } 
}

module.exports = moviesHandler;