const qs = require("querystring");


function addMovie(req, res) {
    if (req.path === "/movie/add" &&req.method === "GET") {
        res.sendHtml("./views/addMovie.html", 200);
    }else  if (req.path === "/movie/add" && req.method === "POST") {
        let body = [];
        req.on('data', (chunk) => {
            body.push(chunk);
        }).on('end', () => {
            body = Buffer.concat(body).toString();
            // at this point, `body` has the entire request body stored in it as a string
            let movieData = qs.parse(body);
            db.push(movieData);

            res.sendHtml("./views/addMovie.html", 200)
        });
    } {
        return true;
    }
}

module.exports = addMovie;