function errorHandler(req, res) {
    res.sendHtml("./views/error.html", 404);
}

module.exports = errorHandler;
